#!/bin/sh
#Creates the file to enter recovery mode
touch /teamspeak/save/recover